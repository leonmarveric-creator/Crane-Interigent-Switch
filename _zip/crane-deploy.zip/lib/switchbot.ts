import crypto from "crypto";

/**
 * SwitchBot OpenAPI v1.1 クライアント。
 * 認証: HMAC-SHA256 署名をヘッダに付与。token / secret はサーバ専用。
 */

const BASE = "https://api.switch-bot.com/v1.1";

interface SwitchBotCreds {
  token: string;
  secret: string;
}

function authHeaders({ token, secret }: SwitchBotCreds) {
  const t = Date.now().toString();
  const nonce = crypto.randomUUID();
  const sign = crypto
    .createHmac("sha256", secret)
    .update(token + t + nonce)
    .digest("base64");

  return {
    Authorization: token,
    sign,
    t,
    nonce,
    "Content-Type": "application/json; charset=utf8",
  };
}

/**
 * 赤外線 (IR) リモコンの仮想デバイスか。
 *   IR: "01-202301011234-12345678" のようにハイフン入り / 実機 (電球・プラグ等): "C271111EC0AB" のような16進。
 */
export function isIrDevice(deviceId: string): boolean {
  return deviceId.includes("-");
}

/**
 * IR の命令は 1 台のハブから順番に送信されるので、同時に送ると取りこぼすことがある。
 * IR だけは 1 つずつ、少し間隔 (IR_GAP_MS) を空けて送る。Wi-Fi の実機は待たずに並行で送る。
 */
const IR_GAP_MS = 350;
let irChain: Promise<unknown> = Promise.resolve();
function queueIr<T>(fn: () => Promise<T>): Promise<T> {
  const run = irChain.then(fn, fn);
  irChain = run.then(
    () => new Promise((r) => setTimeout(r, IR_GAP_MS)),
    () => new Promise((r) => setTimeout(r, IR_GAP_MS)),
  );
  return run;
}

async function postCommand(creds: SwitchBotCreds, deviceId: string, body: object) {
  const res = await fetch(`${BASE}/devices/${deviceId}/commands`, {
    method: "POST",
    headers: authHeaders(creds),
    body: JSON.stringify({ commandType: "command", parameter: "default", ...body }),
    cache: "no-store",
  });
  const payload = await res.json().catch(() => null);
  // SwitchBotは body.statusCode === 100 が成功
  const ok = res.ok && (payload as any)?.statusCode === 100;
  return { ok, status: res.status, payload };
}

async function sendCommand(
  creds: SwitchBotCreds,
  deviceId: string,
  body: { command: string; parameter?: string; commandType?: string }
): Promise<{ ok: boolean; status: number; payload: unknown }> {
  const ir = isIrDevice(deviceId);
  const attempt = () => postCommand(creds, deviceId, body);
  return ir ? queueIr(attempt) : attempt();
}

/** デバイス一覧を取得 (管理画面でID確認用)。 */
export async function listDevices(creds: SwitchBotCreds): Promise<{
  error: string | null;
  deviceList: { deviceId: string; deviceName: string; deviceType: string }[];
  infraredRemoteList: { deviceId: string; deviceName: string; remoteType: string }[];
}> {
  try {
    const res = await fetch(`${BASE}/devices`, {
      headers: authHeaders(creds),
      cache: "no-store",
    });
    const json = await res.json();
    if (json?.statusCode !== 100) {
      return { error: json?.message || `status ${json?.statusCode}`, deviceList: [], infraredRemoteList: [] };
    }
    return {
      error: null,
      deviceList: json.body?.deviceList ?? [],
      infraredRemoteList: json.body?.infraredRemoteList ?? [],
    };
  } catch (e: any) {
    return { error: e?.message || "fetch failed", deviceList: [], infraredRemoteList: [] };
  }
}

/** 仮想IRエアコン: ON / OFF。setAllで温度等の細かい指定も可能。 */
export function acTurnOn(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOn" });
}
export function acTurnOff(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOff" });
}
/** 温度/モード/風量指定 (例: 26度, 冷房, 自動, ON) */
export function acSetAll(
  creds: SwitchBotCreds,
  deviceId: string,
  opts: { temp: number; mode: 1 | 2 | 3 | 4 | 5; fan: 1 | 2 | 3 | 4; power: "on" | "off" }
) {
  // parameter = "{temp},{mode},{fan},{power}"  mode:2=冷房 5=暖房
  return sendCommand(creds, deviceId, {
    command: "setAll",
    parameter: `${opts.temp},${opts.mode},${opts.fan},${opts.power}`,
  });
}

/** DIY (学習リモコン) のボタンを押す: SwitchBot アプリで付けたボタンの名前をそのまま送る (例: 「暖房」「冷房」「停止」) */
export function irCustomButton(creds: SwitchBotCreds, deviceId: string, name: string) {
  return sendCommand(creds, deviceId, { command: name, parameter: "default", commandType: "customize" });
}

/**
 * 汎用デバイス: ON / OFF。
 * SwitchBot Bot / Plug Mini などの物理デバイスも仮想IRも turnOn/turnOff で動く。
 * ギャラクシーモード (プラネタリウムプロジェクター) はこれを使用。
 */
export function deviceTurnOn(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOn" });
}
export function deviceTurnOff(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOff" });
}

/** 仮想IR照明: ON / OFF。光目覚ましもこれを使用。 */
export function lightTurnOn(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOn" });
}
export function lightTurnOff(creds: SwitchBotCreds, deviceId: string) {
  return sendCommand(creds, deviceId, { command: "turnOff" });
}

/**
 * スマート電球 (Color Bulb / テープライト / シーリングライト) の詳細制御。
 * 和風ライトはこれを使用。ON/OFFは deviceTurnOn/Off を流用。
 */
/** 明るさ 1〜100 (%)。 */
export function bulbSetBrightness(creds: SwitchBotCreds, deviceId: string, brightness: number) {
  const v = Math.max(1, Math.min(100, Math.round(brightness)));
  return sendCommand(creds, deviceId, { command: "setBrightness", parameter: String(v) });
}
/** 色温度 2700〜6500 (K)。電球色〜昼光色。 */
export function bulbSetColorTemperature(creds: SwitchBotCreds, deviceId: string, kelvin: number) {
  const v = Math.max(2700, Math.min(6500, Math.round(kelvin)));
  return sendCommand(creds, deviceId, { command: "setColorTemperature", parameter: String(v) });
}
/** フルカラー "R:G:B" (各 0〜255)。 */
export function bulbSetColor(creds: SwitchBotCreds, deviceId: string, rgb: string) {
  // "255:170:90" 形式に正規化 (不正値は無視して 0〜255 にクランプ)。
  const parts = rgb.split(":").map((n) => Math.max(0, Math.min(255, parseInt(n, 10) || 0)));
  const [r, g, b] = [parts[0] ?? 255, parts[1] ?? 255, parts[2] ?? 255];
  return sendCommand(creds, deviceId, { command: "setColor", parameter: `${r}:${g}:${b}` });
}

export type { SwitchBotCreds };

/* ---------- Webhook (SwitchBot から状態の変化を知らせてもらう) ----------
 * 電球・プラグ・シーリングライト (実機) などは、状態が変わるとこちらの URL に知らせが来る (問い合わせの回数を使わない)。
 * 赤外線リモコン (エアコン・IR の照明) は対象外。1 つのアカウントに登録できる URL は 1 つだけ。 */
async function webhookCall(creds: SwitchBotCreds, path: string, body: object): Promise<{ ok: boolean; body: any }> {
  try {
    const res = await fetch(`${BASE}/webhook/${path}`, { method: "POST", headers: authHeaders(creds), body: JSON.stringify(body), cache: "no-store" });
    const j = await res.json().catch(() => null);
    return { ok: res.ok && j?.statusCode === 100, body: j };
  } catch { return { ok: false, body: null }; }
}
/** 登録されている URL (無ければ []) */
export async function webhookQuery(creds: SwitchBotCreds): Promise<{ ok: boolean; urls: string[] }> {
  const r = await webhookCall(creds, "queryWebhook", { action: "queryUrl" });
  const urls = r.body?.body?.urls;
  return { ok: r.ok || r.body?.statusCode === 190, urls: Array.isArray(urls) ? urls.map(String) : [] };
}
export async function webhookSetup(creds: SwitchBotCreds, url: string): Promise<boolean> {
  return (await webhookCall(creds, "setupWebhook", { action: "setupWebhook", url, deviceList: "ALL" })).ok;
}
export async function webhookDelete(creds: SwitchBotCreds, url: string): Promise<boolean> {
  return (await webhookCall(creds, "deleteWebhook", { action: "deleteWebhook", url })).ok;
}
