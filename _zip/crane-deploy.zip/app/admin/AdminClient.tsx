"use client";

import { useEffect, useMemo, useState, useRef, Fragment } from "react";
import { useFormStatus } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus, Copy, Check, Download, RefreshCw, Ban, LogOut, DoorOpen, KeyRound,
  QrCode, Globe, ExternalLink, Snowflake, CalendarDays, ClipboardList, Wrench,
  Image as ImageIcon, History, PowerOff, Loader2, Home, Upload, LampFloor, Droplets,
} from "lucide-react";
import { LANGS, LANG_LABEL } from "@/lib/i18n";
import {
  AT, ADMIN_LANGS, ADMIN_LANG_LABEL, isAdminLang, type AdminLang,
} from "@/lib/adminI18n";
import {
  addReservation, cancelReservation, regeneratePin, setPin, assignDevices, saveAcClimate, updateRoomImage, uploadRoomImage, updateGeofence, syncNow, renameRoom, addRoom, assignReservation,
} from "./actions";
import { navTick, blip, confirm as sfxConfirm } from "@/lib/sfx";
import SmartKeyTab, { SmartKeyPreview, type SmartKeyProps } from "./SmartKeyTab";
import BootVoiceCard from "./BootVoiceCard";
import DriverDesignCard from "./DriverDesignCard";
import PendingCheers, { type PendingCheer } from "./PendingCheers";
import LiveBuilding from "@/components/admin/LiveBuilding";
import { RoomLockForm, type AdminSesameLock } from "./SesameLocks";

export interface Room {
  id: string; slug: string; display_name: string; building: string | null; is_active: boolean;
  ac_device_id: string | null; light_device_id: string | null;
  galaxy_device_id: string | null;
  nest_device_id: string | null;
  wafu_device_id: string | null;
  /** エアコンの暖房・冷房 (migration_ac_climate.sql。未実行なら null) */
  ac_climate?: { policy: string; cool_cmd: string; heat_cmd: string; off_cmd: string; cool_temp: number; heat_temp: number } | null;
  image_url: string | null;
  lat: number | null; lng: number | null; radius: number;
  has_lock?: boolean;
  sesame_lock_id?: string | null;
  url: string; qr: string;
}
export interface Reservation {
  id: string; room_name: string; room_slug: string;
  assigned_room_id: string | null;
  assigned_room_name?: string | null;
  assigned_room_slug?: string | null;
  source: "ical" | "manual"; status: "active" | "cancelled" | "completed";
  guest_name: string | null; guest_lang: string;
  check_in: string; check_out: string;
  unlock_pin: string | null;
  airbnb_reservation_url: string | null;
  /** ゲストがチェックアウトボタンで退室した記録 (同意あり) */
  co?: { at: string; via: string; lang: string; checked: number; total: number; powerOk: boolean | null; policy: string } | null;
}
export interface SwitchBotInfo {
  error: string | null;
  deviceList: { deviceId: string; deviceName: string; deviceType: string }[];
  infraredRemoteList: { deviceId: string; deviceName: string; remoteType: string }[];
}
export interface LogEntry {
  id: string; room_name: string; room_slug: string;
  action: string; source: string; success: boolean; created_at: string;
}
type T = (typeof AT)["ja"];
type Tab = "today" | "reservations" | "rooms" | "smartkey" | "tools";
type ToolsView = "test" | "history";

const LOCALE: Record<AdminLang, string> = { ja: "ja-JP", en: "en-US", zh: "zh-CN" };
const fmt = (iso: string, lang: AdminLang) =>
  new Date(iso).toLocaleString(LOCALE[lang], {
    month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: "Asia/Tokyo",
  });

/* ---------------- 棟(building) の区別ヘルパ ----------------
   Crane Nest（春夏秋冬）と Crane Nest 2（松竹梅林荷）を色分け・グループ化して
   管理しやすくする。既知の棟名は色を固定、未知の棟はニュートラル色。 */
const BUILDING_ORDER = ["Crane Nest", "Crane Nest 2"];
const buildingName = (room: Room): string => room.building || "Crane Nest";
function buildingTone(name: string): string {
  if (name === "Crane Nest 2") return "border-violet-400/40 bg-violet-500/15 text-violet-200";
  if (name === "Crane Nest") return "border-cyan-400/40 bg-cyan-500/15 text-cyan-200";
  return "border-white/20 bg-white/10 text-white/60";
}
function BuildingBadge({ name }: { name: string }) {
  return (
    <span className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold tracking-wide ${buildingTone(name)}`}>
      {name}
    </span>
  );
}
function groupByBuilding(rooms: Room[]): { name: string; rooms: Room[] }[] {
  const map = new Map<string, Room[]>();
  for (const r of rooms) {
    const b = buildingName(r);
    if (!map.has(b)) map.set(b, []);
    map.get(b)!.push(r);
  }
  const names = Array.from(map.keys()).sort((a, b) => {
    const ia = BUILDING_ORDER.indexOf(a);
    const ib = BUILDING_ORDER.indexOf(b);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib) || a.localeCompare(b);
  });
  return names.map((name) => ({ name, rooms: map.get(name)! }));
}

/**
 * 送信ボタン (サーバーアクション用)。
 * 送信中はスピナー、完了後は数秒「✓ 保存しました」を表示して、保存されたことを可視化する。
 * <form action={...}> の中で submit ボタンとして使うこと。
 */
function SubmitButton({
  className, children, savedText, idleIcon,
}: {
  className?: string; children: React.ReactNode; savedText: string; idleIcon?: React.ReactNode;
}) {
  const { pending } = useFormStatus();
  const [saved, setSaved] = useState(false);
  const was = useRef(false);
  useEffect(() => {
    if (was.current && !pending) {
      setSaved(true);
      sfxConfirm();
      const id = setTimeout(() => setSaved(false), 1900);
      was.current = pending;
      return () => clearTimeout(id);
    }
    was.current = pending;
  }, [pending]);
  return (
    <button type="submit" disabled={pending}
      className={`${className ?? ""} transition disabled:opacity-60`}
      aria-busy={pending}>
      {pending ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : saved ? (
        <span className="inline-flex items-center gap-1 text-emerald-300"><Check className="h-3.5 w-3.5" />{savedText}</span>
      ) : (
        <span className="inline-flex items-center gap-1.5">{idleIcon}{children}</span>
      )}
    </button>
  );
}

export default function AdminClient({
  rooms, reservations, switchbot, logs, smartkey, bootVoice = "astralis", driverDesign = "hybrid", pendingCheers = [],
}: { rooms: Room[]; reservations: Reservation[]; switchbot: SwitchBotInfo; logs: LogEntry[]; smartkey: SmartKeyProps; bootVoice?: "astralis" | "jarvis"; driverDesign?: "hybrid" | "bike"; pendingCheers?: PendingCheer[] }) {
  const [lang, setLang] = useState<AdminLang>("ja");
  const [tab, setTab] = useState<Tab>("today");
  const [toolsView, setToolsView] = useState<ToolsView>("test");
  const t = AT[lang];

  useEffect(() => {
    const saved = localStorage.getItem("adminLang");
    if (isAdminLang(saved)) setLang(saved);
  }, []);
  const changeLang = (l: AdminLang) => { setLang(l); localStorage.setItem("adminLang", l); };

  const logout = async () => {
    blip();
    await fetch("/api/admin/logout", { method: "POST" });
    location.href = "/admin/login";
  };

  return (
    <main className="min-h-dvh bg-[#04060c] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="anim-drift absolute -top-32 -left-24 h-96 w-96 rounded-full bg-cyan-500/15 blur-[120px]" />
        <div className="anim-drift2 absolute top-1/2 -right-24 h-96 w-96 rounded-full bg-violet-600/15 blur-[120px]" />
        <div className="anim-grid absolute inset-0
          [background-image:linear-gradient(#22d3ee_1px,transparent_1px),linear-gradient(90deg,#22d3ee_1px,transparent_1px)]
          [background-size:48px_48px]" />
        <div className="anim-scan absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-cyan-300/10 to-transparent" />
        {/* HUDコーナー */}
        <span className="absolute left-3 top-3 h-7 w-7 border-l-2 border-t-2 border-cyan-300/30" />
        <span className="absolute right-3 top-3 h-7 w-7 border-r-2 border-t-2 border-cyan-300/30" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-5 pb-28 pt-8">
        {/* HUDステータスバー */}
        <AdminStatusBar />
        <header className="mb-6 flex items-center justify-between">
          <div>
            <p className="font-mono text-[11px] tracking-[0.3em] text-cyan-400/70">{t.dashboard}</p>
            <h1 className="mt-1 text-xl font-semibold">{t.title}</h1>
          </div>
          <div className="flex items-center gap-2">
            <SyncNowButton t={t} />
            <a href="/admin/tank" title="便槽モニタリング"
              className="flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs text-cyan-200 active:scale-95">
              <Droplets className="h-4 w-4" />
            </a>
            <LangSwitch lang={lang} onChange={changeLang} />
            <button onClick={logout}
              className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs active:scale-95">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>

        {tab === "today" && <><PendingCheers items={pendingCheers} /><TodayTab rooms={rooms} reservations={reservations} t={t} lang={lang} /></>}
        {tab === "reservations" && <ReservationsTab rooms={rooms} reservations={reservations} t={t} lang={lang} />}
        {tab === "rooms" && <RoomsTab rooms={rooms} info={switchbot} t={t} locks={smartkey.locks} locksMissing={smartkey.locksMissing} lang={lang} />}
        {tab === "smartkey" && (
          <SmartKeyTab {...smartkey} rooms={rooms} reservations={reservations} lang={lang}
            onOpenPreview={() => { navTick(); setToolsView("test"); setTab("tools"); window.scrollTo(0, 0); }} />
        )}
        {tab === "tools" && (
          <>
            {/* ツール: テスト / 履歴 を切り替え (下ナビを5つに収めるため統合) */}
            <div className="mb-5 grid grid-cols-2 gap-1 rounded-full border border-white/10 bg-white/5 p-1 text-xs font-semibold">
              {([["test", t.tabTest, Wrench], ["history", t.tabHistory, History]] as const).map(([k, label, Icon]) => (
                <button key={k} onClick={() => { if (toolsView !== k) navTick(); setToolsView(k); }}
                  className={`flex items-center justify-center gap-1.5 rounded-full py-2 transition ${toolsView === k ? "bg-cyan-500/20 text-cyan-100 shadow-[0_0_14px_-4px_rgba(34,211,238,0.7)]" : "text-white/50"}`}>
                  <Icon className="h-4 w-4" /> {label}
                </button>
              ))}
            </div>
            {toolsView === "test" && (
              <div className="space-y-10">
                <BootVoiceCard initial={bootVoice} lang={lang} />
                <DriverDesignCard initial={driverDesign} lang={lang} />
                <DeviceTestSection rooms={rooms} t={t} />
                <SmartKeyPreview entrances={smartkey.entrances} settings={smartkey.settings} rooms={rooms} lang={lang} />
              </div>
            )}
            {toolsView === "history" && <HistoryTab logs={logs} rooms={rooms} t={t} lang={lang} />}
          </>
        )}
      </div>

      <BottomNav tab={tab} setTab={setTab} t={t} />
    </main>
  );
}

/* ---------------- HUDステータスバー ---------------- */
function AdminStatusBar() {
  const [clock, setClock] = useState("--:--:--");
  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString("en-GB", { timeZone: "Asia/Tokyo" }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="anim-flicker mb-4 flex items-center justify-between rounded-full border border-cyan-400/20 bg-cyan-400/[0.04] px-4 py-1.5 font-mono text-[9px] tracking-[0.25em] text-cyan-300/70">
      <span className="flex items-center gap-1.5">
        <span className="anim-breathe inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" /> HOST TERMINAL
      </span>
      <span className="tracking-[0.2em] text-cyan-200/80">{clock} JST</span>
      <span className="hidden items-end gap-0.5 sm:flex">
        {[3, 5, 4, 6, 5].map((h, i) => (
          <span key={i} className="anim-breathe inline-block w-0.5 bg-cyan-400/70"
            style={{ height: h, animationDelay: `${i * 0.18}s` }} />
        ))}
      </span>
    </div>
  );
}

/* ---------------- Bottom nav ---------------- */
function BottomNav({ tab, setTab, t }: { tab: Tab; setTab: (t: Tab) => void; t: T }) {
  const items: { key: Tab; label: string; Icon: any }[] = [
    { key: "today", label: t.tabToday, Icon: CalendarDays },
    { key: "reservations", label: t.tabReservations, Icon: ClipboardList },
    { key: "rooms", label: t.tabRooms, Icon: DoorOpen },
    { key: "smartkey", label: t.tabSmartKey, Icon: KeyRound },
    { key: "tools", label: t.tabTools, Icon: Wrench },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-cyan-400/20 bg-[#070a12]/90 backdrop-blur-xl">
      {/* 上端に流れる光 */}
      <div className="pointer-events-none absolute inset-x-0 -top-px h-px overflow-hidden">
        <div className="h-px w-1/3 bg-gradient-to-r from-transparent via-cyan-300/80 to-transparent"
          style={{ animation: "streamX 4s linear infinite" }} />
      </div>
      <div className="mx-auto flex max-w-5xl">
        {items.map(({ key, label, Icon }) => {
          const active = tab === key;
          return (
            <button key={key} onClick={() => { if (!active) navTick(); setTab(key); }}
              className={`relative flex flex-1 flex-col items-center gap-1 py-3 text-[11px] transition
                ${active ? "text-cyan-300" : "text-white/45"}`}>
              {active && (
                <span className="pointer-events-none absolute inset-x-3 inset-y-1 rounded-xl bg-cyan-400/[0.07]
                  shadow-[0_0_18px_-4px_rgba(34,211,238,0.6)_inset]" />
              )}
              <Icon className={`h-5 w-5 ${active ? "drop-shadow-[0_0_6px_rgba(34,211,238,0.9)]" : ""}`} />
              {label}
              {active && <span className="absolute bottom-0 h-0.5 w-10 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9)]" />}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

/* ---------------- Today tab ---------------- */
const jstDay = (iso: number | string) =>
  new Date(iso).toLocaleDateString("en-CA", { timeZone: "Asia/Tokyo" }); // YYYY-MM-DD

/* ゲストのチェックアウト (ボタン・同意あり) */
const CO_L: Record<AdminLang, { done: string; notYet: string; items: string; power: string; powerNg: string; via: Record<string, string>; policy: string }> = {
  ja: { done: "チェックアウト済み・同意あり", notYet: "未チェックアウト（時刻を過ぎています）", items: "項目確認", power: "電源 OFF OK", powerNg: "電源 OFF 失敗", via: { room: "お部屋の画面", concierge: "コンシェルジュ" }, policy: "同意した文面" },
  en: { done: "Checked out · consent", notYet: "Not checked out (past time)", items: "items checked", power: "Power off OK", powerNg: "Power off failed", via: { room: "Room screen", concierge: "Concierge" }, policy: "Agreed text" },
  zh: { done: "已退房・已同意", notYet: "未退房（已过时间）", items: "项已确认", power: "已断电", powerNg: "断电失败", via: { room: "房间页面", concierge: "礼宾服务" }, policy: "同意的文字" },
};
function CheckoutBadge({ co, lang }: { co: NonNullable<Reservation["co"]>; lang: AdminLang }) {
  const k = CO_L[lang];
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={() => setOpen((v) => !v)} className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[11px] font-semibold text-emerald-300">
        ✓ {k.done}
      </button>
      <p className="mt-1 text-[10.5px] text-white/45">
        {fmt(co.at, lang)} · {co.lang} · {co.checked}/{co.total} {k.items} · {co.powerOk === false ? k.powerNg : k.power}
      </p>
      {open && (
        <p className="mt-1 max-w-xs text-[10.5px] leading-relaxed text-white/55">
          {k.via[co.via] ?? co.via} · {k.policy}: 「{co.policy}」
        </p>
      )}
    </div>
  );
}

function TodayTab({ rooms, reservations, t, lang }: { rooms: Room[]; reservations: Reservation[]; t: T; lang: AdminLang }) {
  const now = Date.now();
  const today = jstDay(now);

  // 各部屋: 今滞在中 > 今日これから到着 の順で「今日のゲスト」を選ぶ
  const todayByRoom = useMemo(() => {
    const m = new Map<string, { r: Reservation; state: "staying" | "arriving" | "left" }>();
    for (const room of rooms) {
      const active = reservations.find((r) =>
        r.room_slug === room.slug && r.status === "active" &&
        new Date(r.check_in).getTime() <= now && now < new Date(r.check_out).getTime()
      );
      if (active) { m.set(room.slug, { r: active, state: "staying" }); continue; }
      const arriving = reservations
        .filter((r) => r.room_slug === room.slug && r.status === "active"
          && new Date(r.check_in).getTime() > now && jstDay(r.check_in) === today)
        .sort((a, b) => new Date(a.check_in).getTime() - new Date(b.check_in).getTime())[0];
      if (arriving) { m.set(room.slug, { r: arriving, state: "arriving" }); continue; }
      // 今日チェックアウトの時刻を過ぎた予約 (ボタンで済んだか / 未か を出す)
      const left = reservations
        .filter((r) => r.room_slug === room.slug && r.status === "active"
          && new Date(r.check_out).getTime() <= now && jstDay(r.check_out) === today)
        .sort((a, b) => new Date(b.check_out).getTime() - new Date(a.check_out).getTime())[0];
      if (left) m.set(room.slug, { r: left, state: "left" });
    }
    return m;
  }, [reservations, rooms, now, today]);

  const anyToday = rooms.some((r) => todayByRoom.has(r.slug));

  return (
    <section>
      {/* LIVE: 建物のホログラムで、どの部屋の明かり・エアコンがついているか (今の表はそのまま、上に 1 枠足すだけ) */}
      <LiveBuilding lang={lang} />
      <div className="mb-3 flex items-center gap-2 text-sm text-cyan-200">
        <CalendarDays className="h-4 w-4" /> {t.todayTitle}
      </div>
      <div className="clip-bevel overflow-hidden border border-cyan-400/15 bg-[#070a12]/80 backdrop-blur-xl">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wide text-white/40">
            <tr className="border-b border-white/10">
              <th className="px-4 py-3">{t.tabRooms}</th>
              <th className="px-2 py-3">{t.status}</th>
              <th className="px-2 py-3">{t.period}</th>
              <th className="px-2 py-3">{t.pin}</th>
              <th className="px-2 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {groupByBuilding(rooms).map((group) => (
              <Fragment key={group.name}>
                <tr className="bg-white/[0.03]">
                  <td colSpan={5} className="px-4 py-2">
                    <BuildingBadge name={group.name} />
                  </td>
                </tr>
                {group.rooms.map((room) => {
              const hit = todayByRoom.get(room.slug);
              const r = hit?.r;
              return (
                <tr key={room.id} className="border-b border-white/5 last:border-0">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <RoomThumb room={room} size={32} />
                      <span className="font-medium">{room.display_name}</span>
                      {r?.assigned_room_id && (
                        <span className="rounded-full border border-violet-400/40 bg-violet-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-violet-200">
                          → {r.assigned_room_name}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-2 py-3">
                    {!hit
                      ? <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] text-white/40">{t.empty}</span>
                      : r?.co
                        ? <CheckoutBadge co={r.co} lang={lang} />
                        : hit.state === "left"
                          ? <span className="rounded-full bg-orange-500/20 px-2 py-0.5 text-[11px] font-semibold text-orange-300">{CO_L[lang].notYet}</span>
                          : hit.state === "staying"
                            ? <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] text-emerald-300">{t.staying}</span>
                            : <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] text-amber-300">{t.arriving}</span>}
                  </td>
                  <td className="px-2 py-3 text-[11px] text-white/60">
                    {r ? `${fmt(r.check_in, lang)} → ${fmt(r.check_out, lang)}` : "—"}
                  </td>
                  <td className="px-2 py-3 font-mono text-cyan-200">{r?.unlock_pin ?? "—"}</td>
                  <td className="px-2 py-3">
                    {r?.airbnb_reservation_url && (
                      <a href={r.airbnb_reservation_url} target="_blank" rel="noopener noreferrer"
                        className="text-rose-300/80 hover:text-rose-300"><ExternalLink className="h-4 w-4" /></a>
                    )}
                  </td>
                </tr>
              );
                })}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
      {!anyToday && <p className="mt-3 text-center text-xs text-white/40">{t.todayNone}</p>}
    </section>
  );
}

/* ---------------- Reservations tab ---------------- */
function ReservationsTab({ rooms, reservations, t, lang }: { rooms: Room[]; reservations: Reservation[]; t: T; lang: AdminLang }) {
  const [filter, setFilter] = useState<string>("all");
  const [assignMode, setAssignMode] = useState(false); // 客室割り当て（寄せ）モード
  const shown = useMemo(
    () => reservations.filter((r) => filter === "all" || r.room_slug === filter),
    [reservations, filter]
  );
  return (
    <section>
      <div className="clip-bevel mb-6 border border-cyan-400/15 bg-[#070a12]/80 p-5 backdrop-blur-xl">
        <div className="mb-4 flex items-center gap-2 text-sm text-emerald-200">
          <Plus className="h-4 w-4" /> {t.addTitle}
        </div>
        <form action={addReservation} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label={t.room}>
            <select name="room_id" required className={selCls}>
              {rooms.map((r) => <option key={r.id} value={r.id}>{r.display_name}（{r.slug}）</option>)}
            </select>
          </Field>
          <Field label={t.language}>
            <select name="guest_lang" defaultValue="en" className={selCls}>
              {LANGS.map((l) => <option key={l} value={l}>{LANG_LABEL[l]}</option>)}
            </select>
          </Field>
          <Field label={t.checkIn}>
            <input type="datetime-local" name="check_in" required className={selCls} />
          </Field>
          <Field label={t.checkOut}>
            <input type="datetime-local" name="check_out" required className={selCls} />
          </Field>
          <Field label={`${t.guestName}（${t.optional}）`}>
            <input type="text" name="guest_name" placeholder="—" className={selCls} />
          </Field>
          <Field label={t.pinField}>
            <input type="text" name="unlock_pin" inputMode="numeric" placeholder={t.autoPlaceholder} maxLength={6} className={`${selCls} font-mono`} />
          </Field>
          <SubmitButton savedText={t.saved} idleIcon={<Plus className="h-4 w-4" />}
            className="sm:col-span-2 flex items-center justify-center gap-2 rounded-xl border border-emerald-400/50 bg-emerald-500/15 py-3 text-sm text-emerald-200 active:bg-emerald-500/30">
            {t.addButton}
          </SubmitButton>
        </form>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")} label={t.all} />
        {rooms.map((r) => <FilterChip key={r.id} active={filter === r.slug} onClick={() => setFilter(r.slug)} label={r.display_name} />)}
        <button
          onClick={() => { blip(); setAssignMode((v) => !v); }}
          className={`ml-auto flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${assignMode ? "border-violet-400/50 bg-violet-500/20 text-violet-100" : "border-white/10 bg-white/5 text-white/55"}`}
          title="看板の付け替え運用に合わせ、予約を別の部屋に寄せる"
        >
          <DoorOpen className="h-3.5 w-3.5" /> 客室割り当て
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {shown.map((r) => <ReservationCard key={r.id} r={r} rooms={rooms} assignMode={assignMode} t={t} lang={lang} />)}
        {shown.length === 0 && <p className="col-span-full py-12 text-center text-sm text-white/40">{t.noReservations}</p>}
      </div>
    </section>
  );
}

/* ---------------- History tab ---------------- */
function HistoryTab({ logs, rooms, t, lang }: { logs: LogEntry[]; rooms: Room[]; t: T; lang: AdminLang }) {
  const [filter, setFilter] = useState<string>("all");
  const actionLabel: Record<string, string> = {
    unlock: t.unlock, lock: t.lock, ac_on: t.acOn, ac_off: t.acOff, light_on: t.lightOn, light_off: t.lightOff,
    galaxy_on: t.galaxyOn, galaxy_off: t.galaxyOff, nest_on: t.nestOn, nest_off: t.nestOff, wafu_on: t.wafuOn, wafu_off: t.wafuOff,
    wafu_on_warm: t.wafuOn, wafu_warm: t.wafuWarm, wafu_brightness: t.wafuBrightness,
    wafu_temp: t.wafuTemp, wafu_color: t.wafuColor, welcome: t.welcomeScene, welcome_cozy: t.cozyScene, good_night: t.goodNightScene, away: t.checkoutOff,
  };
  const srcLabel: Record<string, string> = { guest: t.srcGuest, admin: t.srcAdmin, cron: t.srcCron };
  const shown = useMemo(() => logs.filter((l) => filter === "all" || l.room_slug === filter), [logs, filter]);

  return (
    <section>
      <div className="mb-3 flex items-center gap-2 text-sm text-cyan-200">
        <History className="h-4 w-4" /> {t.historyTitle}
      </div>
      <div className="mb-4 flex flex-wrap gap-2">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")} label={t.all} />
        {rooms.map((r) => <FilterChip key={r.id} active={filter === r.slug} onClick={() => setFilter(r.slug)} label={r.display_name} />)}
      </div>
      <div className="clip-bevel overflow-hidden border border-cyan-400/15 bg-[#070a12]/80 backdrop-blur-xl">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wide text-white/40">
            <tr className="border-b border-white/10">
              <th className="px-3 py-3">{t.when}</th>
              <th className="px-2 py-3">{t.tabRooms}</th>
              <th className="px-2 py-3">{t.unlock}/{t.acOn}</th>
              <th className="px-2 py-3">{t.status}</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((l) => (
              <tr key={l.id} className="border-b border-white/5 last:border-0">
                <td className="px-3 py-2.5 text-[11px] text-white/60">{fmt(l.created_at, lang)}</td>
                <td className="px-2 py-2.5 text-xs">{l.room_name}</td>
                <td className="px-2 py-2.5 text-xs">
                  <span className="text-white/80">{actionLabel[l.action] ?? l.action}</span>
                  <span className="ml-1 text-[10px] text-white/35">· {srcLabel[l.source] ?? l.source}</span>
                </td>
                <td className="px-2 py-2.5">
                  {l.success
                    ? <Check className="h-4 w-4 text-emerald-300" />
                    : <span className="text-rose-300">×</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {shown.length === 0 && <p className="mt-3 text-center text-xs text-white/40">{t.noLogs}</p>}
    </section>
  );
}

/* ---------------- Rooms tab ---------------- */
function RoomsTab({ rooms, info, t, locks, locksMissing, lang }: { rooms: Room[]; info: SwitchBotInfo; t: T; locks: AdminSesameLock[]; locksMissing: boolean; lang: AdminLang }) {
  const [filter, setFilter] = useState<string>("all"); // 棟フィルタ ("all" | 棟名)
  const [showAdd, setShowAdd] = useState(false);        // 「部屋を追加」フォームの開閉
  const ir = info.infraredRemoteList ?? [];
  const acs = ir.filter((d) => /air\s*conditioner/i.test(d.remoteType));
  const lights = ir.filter((d) => /light/i.test(d.remoteType));
  // 和風ライト候補: スマート電球/テープライト/プラグ等の物理デバイス + 照明系IRリモコン
  const wafus = [
    ...(info.deviceList ?? [])
      .filter((d) => /bulb|light|strip|lamp|plug|bot|ceiling/i.test(d.deviceType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
    ...ir
      .filter((d) => /light/i.test(d.remoteType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
  ];
  // ギャラクシー(プラネタリウム)候補: Bot/Plug等の物理デバイス + プロジェクター系IRリモコン
  const galaxies = [
    ...(info.deviceList ?? [])
      .filter((d) => /bot|plug/i.test(d.deviceType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
    ...ir
      .filter((d) => /projector|others|diy|tv/i.test(d.remoteType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
  ];
  // NEST(藤編みボールランプ)候補: Bot/Plug等の物理デバイス + 照明/その他系IRリモコン
  const nests = [
    ...(info.deviceList ?? [])
      .filter((d) => /bot|plug|bulb|light|strip|lamp/i.test(d.deviceType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
    ...ir
      .filter((d) => /light|others|diy/i.test(d.remoteType))
      .map((d) => ({ deviceId: d.deviceId, deviceName: d.deviceName })),
  ];
  const groups = groupByBuilding(rooms);
  const visibleGroups = filter === "all" ? groups : groups.filter((g) => g.name === filter);

  return (
    <section>
      {/* 棟フィルタ + 追加トグル（スクロールしても上部に固定） */}
      <div className="sticky top-0 z-20 -mx-1 mb-4 flex flex-wrap items-center gap-2 bg-[#04060c]/85 px-1 py-2 backdrop-blur-xl">
        <button
          onClick={() => { navTick(); setFilter("all"); }}
          className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${filter === "all" ? "border-cyan-400/50 bg-cyan-500/20 text-cyan-100" : "border-white/10 bg-white/5 text-white/50"}`}
        >
          ALL <span className="opacity-60">{rooms.length}</span>
        </button>
        {groups.map((g) => (
          <button
            key={g.name}
            onClick={() => { navTick(); setFilter(g.name); }}
            className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${filter === g.name ? `${buildingTone(g.name)} ring-1 ring-white/15` : "border-white/10 bg-white/5 text-white/50"}`}
          >
            {g.name} <span className="opacity-60">{g.rooms.length}</span>
          </button>
        ))}
        <button
          onClick={() => { blip(); setShowAdd((v) => !v); }}
          className="ml-auto flex items-center gap-1 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-200"
        >
          <Plus className="h-3.5 w-3.5" /> {t.addRoomTitle}
        </button>
      </div>

      {/* 部屋を追加（開閉式・既定は閉じる） */}
      {showAdd && (
        <div className="clip-bevel mb-6 border border-emerald-400/20 bg-[#070a12]/80 p-5 backdrop-blur-xl">
          <form action={addRoom} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Field label={t.roomNameLabel}>
              <input type="text" name="display_name" required placeholder="AKI" className={selCls} />
            </Field>
            <Field label={t.slugLabel}>
              <input type="text" name="slug" required placeholder="aki" pattern="[a-zA-Z0-9\-\s]+"
                className={`${selCls} font-mono lowercase`} />
            </Field>
            <Field label="棟 / Building">
              <select name="building" defaultValue={filter === "all" ? "Crane Nest" : filter} className={selCls}>
                <option value="Crane Nest">Crane Nest</option>
                <option value="Crane Nest 2">Crane Nest 2</option>
              </select>
            </Field>
            <div className="sm:col-span-2">
              <Field label={t.icalLabel}>
                <input type="text" name="airbnb_ical_url" placeholder="https://www.airbnb.com/calendar/ical/..." className={`${selCls} text-xs`} />
              </Field>
            </div>
            <p className="text-[10px] text-white/35 sm:col-span-2">💡 {t.slugHint}</p>
            <SubmitButton savedText={t.saved} idleIcon={<Plus className="h-4 w-4" />}
              className="sm:col-span-2 flex items-center justify-center gap-2 rounded-xl border border-emerald-400/50 bg-emerald-500/15 py-3 text-sm text-emerald-200 active:bg-emerald-500/30">
              {t.addRoomBtn}
            </SubmitButton>
          </form>
        </div>
      )}

      {visibleGroups.map((group) => (
        <div key={group.name} className="mb-6">
          <div className="mb-3 flex items-center gap-2">
            <BuildingBadge name={group.name} />
            <span className="text-[11px] text-white/40">{group.rooms.length} {t.tabRooms}</span>
            <span className="h-px flex-1 bg-white/10" />
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {group.rooms.map((room) => (
              <RoomManageCard key={room.id} room={room} acs={acs} lights={lights} galaxies={galaxies} nests={nests} wafus={wafus} sbError={info.error} t={t} locks={locks} locksMissing={locksMissing} lang={lang} />
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}

function RoomManageCard({
  room, acs, lights, galaxies, nests, wafus, sbError, t, locks, locksMissing, lang,
}: {
  locks: AdminSesameLock[]; locksMissing: boolean; lang: AdminLang;
  room: Room;
  acs: { deviceId: string; deviceName: string }[];
  lights: { deviceId: string; deviceName: string }[];
  galaxies: { deviceId: string; deviceName: string }[];
  nests: { deviceId: string; deviceName: string }[];
  wafus: { deviceId: string; deviceName: string }[];
  sbError: string | null;
  t: T;
}) {
  const [copied, setCopied] = useState(false);
  const opt = (d: { deviceId: string; deviceName: string }) => (
    <option key={d.deviceId} value={d.deviceId}>{d.deviceName || d.deviceId}</option>
  );
  return (
    <div className="clip-bevel overflow-hidden border border-cyan-400/15 bg-[#070a12]/80 backdrop-blur-xl">
      <div className="flex gap-3 p-4">
        <RoomThumb room={room} size={72} />
        <div className="min-w-0 flex-1">
          {/* 表示名の変更 (slugとQRはそのまま) */}
          <form action={renameRoom} className="flex items-center gap-1.5">
            <input type="hidden" name="room_id" value={room.id} />
            <input type="text" name="display_name" defaultValue={room.display_name} required
              className="w-full min-w-0 rounded-lg border border-transparent bg-transparent px-1 py-0.5 font-medium
                focus:border-cyan-400/50 focus:bg-black/40 focus:outline-none" />
            <SubmitButton savedText="✓" className="shrink-0 rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-2 py-1 text-[10px] text-cyan-200">
              {t.rename}
            </SubmitButton>
          </form>
          <div className="mt-0.5 flex items-center gap-2">
            <p className="font-mono text-[11px] text-white/40">{room.slug}</p>
            <BuildingBadge name={buildingName(room)} />
          </div>
          <div className="mt-2 flex gap-2">
            <button onClick={async () => { await navigator.clipboard.writeText(room.url); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
              className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-white/60">
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : <Copy className="h-3.5 w-3.5" />} URL
            </button>
            <a href={room.qr} download={`qr-${room.slug}.png`}
              className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-white/60">
              <Download className="h-3.5 w-3.5" /> QR
            </a>
          </div>
        </div>
        <img src={room.qr} alt="QR" className="h-16 w-16 rounded-lg bg-white p-1" />
      </div>

      {/* 鍵（Sesame）: Sesame 一覧から選ぶ */}
      {!locksMissing && (
        <div className="border-t border-white/10 p-4">
          <RoomLockForm roomId={room.id} value={room.sesame_lock_id ?? null} hasLegacy={!!room.has_lock && !room.sesame_lock_id} locks={locks} lang={lang} />
        </div>
      )}

      {/* デバイス割り当て */}
      <div className="border-t border-white/10 p-4">
        {sbError ? (
          <p className="text-[11px] text-amber-300/80">{sbError}</p>
        ) : (
          <form action={assignDevices} className="flex flex-wrap items-end gap-2">
            <input type="hidden" name="room_id" value={room.id} />
            <label className="flex-1 text-[11px] text-white/50">{t.ac}
              <select name="ac" defaultValue={room.ac_device_id ?? ""} className={`${selCls} mt-1 py-2 text-xs`}>
                <option value="">{t.none}</option>{acs.map(opt)}
              </select>
            </label>
            <label className="flex-1 text-[11px] text-white/50">{t.light}
              <select name="light" defaultValue={room.light_device_id ?? ""} className={`${selCls} mt-1 py-2 text-xs`}>
                <option value="">{t.none}</option>{lights.map(opt)}
              </select>
            </label>
            {/* ギャラクシーモード: プラネタリウムプロジェクターのSwitchBot (割り当てるとゲスト画面に出現) */}
            <label className="w-full text-[11px] text-violet-300/80">
              <span className="flex items-center gap-1">{t.galaxy}
                {room.galaxy_device_id && <span className="rounded-full bg-violet-500/20 px-1.5 py-0.5 text-[9px] tracking-widest text-violet-200">ENABLED</span>}
              </span>
              <select name="galaxy" defaultValue={room.galaxy_device_id ?? ""} className={`${selCls} mt-1 border-violet-400/30 py-2 text-xs`}>
                <option value="">{t.none}</option>{galaxies.map(opt)}
              </select>
            </label>
            {/* NESTモード: 藤編みボールランプのSwitchBot (割り当てるとゲスト画面に出現) */}
            <label className="w-full text-[11px] text-amber-300/80">
              <span className="flex items-center gap-1">{t.nest}
                {room.nest_device_id && <span className="rounded-full bg-amber-500/20 px-1.5 py-0.5 text-[9px] tracking-widest text-amber-200">ENABLED</span>}
              </span>
              <select name="nest" defaultValue={room.nest_device_id ?? ""} className={`${selCls} mt-1 border-amber-400/30 py-2 text-xs`}>
                <option value="">{t.none}</option>{nests.map(opt)}
              </select>
            </label>
            {/* 和風ライト(行灯): スマート電球のSwitchBot (割り当てるとゲスト画面に出現) */}
            <label className="w-full text-[11px] text-rose-300/80">
              <span className="flex items-center gap-1">{t.wafu}
                {room.wafu_device_id && <span className="rounded-full bg-rose-500/20 px-1.5 py-0.5 text-[9px] tracking-widest text-rose-200">ENABLED</span>}
              </span>
              <select name="wafu" defaultValue={room.wafu_device_id ?? ""} className={`${selCls} mt-1 border-rose-400/30 py-2 text-xs`}>
                <option value="">{t.none}</option>{wafus.map(opt)}
              </select>
            </label>
            <SubmitButton savedText={t.saved} className="rounded-lg border border-emerald-400/50 bg-emerald-500/15 px-3 py-2 text-xs text-emerald-200">{t.save}</SubmitButton>
          </form>
        )}
      </div>

      {/* エアコンの暖房・冷房 (DIY 登録は SwitchBot アプリのボタン名をそのまま) */}
      {room.ac_device_id && (
        <div className="border-t border-white/10 p-4">
          {!room.ac_climate ? (
            <p className="text-[11px] text-amber-300/80">❄️🔥 暖房・冷房の登録には Supabase で supabase/migration_ac_climate.sql を実行してください</p>
          ) : (
            <form action={saveAcClimate} className="grid grid-cols-2 gap-2">
              <input type="hidden" name="room_id" value={room.id} />
              <p className="col-span-2 text-[11px] font-bold tracking-widest text-sky-200/80">❄️🔥 エアコン（暖房・冷房）</p>
              <label className="col-span-2 text-[11px] text-white/50">つけ方
                <select name="policy" defaultValue={room.ac_climate.policy} className={`${selCls} mt-1 py-2 text-xs`}>
                  <option value="auto">自動（季節 + 外の気温：24℃以上→冷房／18℃以下→暖房）</option>
                  <option value="cool">いつも冷房</option>
                  <option value="heat">いつも暖房</option>
                </select>
              </label>
              <label className="text-[11px] text-sky-300/80">冷房のボタン名（DIY）
                <input name="cool_cmd" defaultValue={room.ac_climate.cool_cmd} placeholder="例：冷房" className={`${selCls} mt-1 py-2 text-xs`} />
              </label>
              <label className="text-[11px] text-orange-300/80">暖房のボタン名（DIY）
                <input name="heat_cmd" defaultValue={room.ac_climate.heat_cmd} placeholder="例：暖房" className={`${selCls} mt-1 py-2 text-xs`} />
              </label>
              <label className="text-[11px] text-white/50">停止のボタン名（DIY・任意）
                <input name="off_cmd" defaultValue={room.ac_climate.off_cmd} placeholder="例：停止" className={`${selCls} mt-1 py-2 text-xs`} />
              </label>
              <div className="flex gap-2">
                <label className="flex-1 text-[11px] text-sky-300/80">冷房℃
                  <input name="cool_temp" type="number" min={16} max={30} defaultValue={room.ac_climate.cool_temp} className={`${selCls} mt-1 py-2 text-xs`} />
                </label>
                <label className="flex-1 text-[11px] text-orange-300/80">暖房℃
                  <input name="heat_temp" type="number" min={16} max={30} defaultValue={room.ac_climate.heat_temp} className={`${selCls} mt-1 py-2 text-xs`} />
                </label>
              </div>
              <p className="col-span-2 text-[10px] leading-relaxed text-white/40">ボタン名は SwitchBot アプリでこのエアコンに学習させたボタンの名前と完全に同じにしてください（空欄なら「エアコン」登録として温度で指定）。℃は「エアコン」登録のときに使います。</p>
              <div className="col-span-2"><SubmitButton savedText={t.saved} className="rounded-lg border border-emerald-400/50 bg-emerald-500/15 px-3 py-2 text-xs text-emerald-200">{t.save}</SubmitButton></div>
            </form>
          )}
        </div>
      )}

      {/* 画像: ファイルアップロード */}
      <form action={uploadRoomImage} className="flex items-end gap-2 border-t border-white/10 p-4">
        <input type="hidden" name="room_id" value={room.id} />
        <label className="flex-1 text-[11px] text-white/50">
          <span className="flex items-center gap-1"><ImageIcon className="h-3 w-3" /> {t.uploadImage} <span className="text-white/30">(≤4MB)</span></span>
          <input type="file" name="image" accept="image/*,video/*" required
            className="mt-1 block w-full text-xs text-white/70 file:mr-2 file:rounded-lg file:border file:border-violet-400/50
              file:bg-violet-500/15 file:px-3 file:py-1.5 file:text-violet-200" />
        </label>
        <SubmitButton savedText={t.saved} idleIcon={<Upload className="h-3.5 w-3.5" />}
          className="rounded-lg border border-violet-400/50 bg-violet-500/15 px-3 py-2 text-xs text-violet-200">{t.uploadImage}</SubmitButton>
      </form>

      {/* 画像URL (任意・直接指定したい場合) */}
      <form action={updateRoomImage} className="flex items-end gap-2 border-t border-white/10 px-4 pb-4">
        <input type="hidden" name="room_id" value={room.id} />
        <label className="flex-1 text-[11px] text-white/50">
          <span className="flex items-center gap-1"><ImageIcon className="h-3 w-3" /> {t.imageUrlLabel}</span>
          <input type="text" name="image_url" defaultValue={room.image_url ?? ""} placeholder="https://... or /rooms/room-xxx.jpg" className={`${selCls} mt-1 py-2 text-xs`} />
        </label>
        <SubmitButton savedText={t.saved} className="rounded-lg border border-violet-400/50 bg-violet-500/15 px-3 py-2 text-xs text-violet-200">{t.save}</SubmitButton>
      </form>

      {/* ウェルカム / 退室クリーンアップ */}
      <div className="grid grid-cols-2 gap-2 border-t border-white/10 p-4">
        <SceneButton slug={room.slug} action="welcome" label={t.welcomeScene} tone="emerald" />
        <SceneButton slug={room.slug} action="away" label={t.checkoutOff} tone="amber" />
        {room.wafu_device_id && (
          <div className="col-span-2">
            <SceneButton slug={room.slug} action="welcome_cozy" label={t.cozyScene} tone="rose" />
          </div>
        )}
      </div>

      {/* ジオフェンス (位置制限) */}
      <form action={updateGeofence} className="border-t border-white/10 p-4">
        <input type="hidden" name="room_id" value={room.id} />
        {/* タイトル + 大きめON/OFFトグル (現在状態を表示) */}
        <div className="mb-3 flex items-center justify-between gap-3">
          <p className="text-[11px] text-white/50">📍 {t.geofenceTitle}</p>
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input type="checkbox" name="geofence_on" aria-label={t.geofenceEnable} defaultChecked={room.radius > 0} className="peer sr-only" />
            <span className="font-mono text-[10px] tracking-widest text-white/40 peer-checked:hidden">OFF</span>
            <span className="hidden font-mono text-[10px] tracking-widest text-emerald-300 peer-checked:inline">ON</span>
            <span className="relative h-6 w-11 rounded-full bg-white/15 transition-colors peer-checked:bg-emerald-500/70
              after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow
              after:transition-transform after:content-[''] peer-checked:after:translate-x-5" />
          </label>
        </div>
        <p className="mb-2 text-[10px] text-white/35">{t.geofenceHint}</p>
        <div className="flex items-end gap-2">
          <input type="text" name="lat" inputMode="decimal" defaultValue={room.lat ?? ""} placeholder="lat 35.0000" className={`${selCls} py-2 text-xs`} />
          <input type="text" name="lng" inputMode="decimal" defaultValue={room.lng ?? ""} placeholder="lng 135.0000" className={`${selCls} py-2 text-xs`} />
          <input type="text" name="radius" inputMode="numeric" defaultValue={room.radius || 150} placeholder="150" className="w-20 rounded-xl border border-white/10 bg-black/40 px-2 py-2 text-center text-xs text-white" />
          <SubmitButton savedText={t.saved} className="rounded-lg border border-cyan-400/50 bg-cyan-500/15 px-3 py-2 text-xs text-cyan-200">{t.save}</SubmitButton>
        </div>
      </form>
    </div>
  );
}

function SceneButton({ slug, action, label, tone }: {
  slug: string; action: "welcome" | "welcome_cozy" | "away"; label: string; tone: "emerald" | "amber" | "rose";
}) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const run = async () => {
    setBusy(true); setDone(false);
    try {
      await fetch("/api/admin/test-device", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roomSlug: slug, action }),
      });
      setDone(true); setTimeout(() => setDone(false), 2000);
    } catch { /* ignore */ }
    setBusy(false);
  };
  const cls = tone === "emerald"
    ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-200 active:bg-emerald-500/20"
    : tone === "rose"
    ? "border-rose-400/40 bg-rose-500/10 text-rose-200 active:bg-rose-500/20"
    : "border-amber-400/40 bg-amber-500/10 text-amber-200 active:bg-amber-500/20";
  const Icon = action === "welcome" ? Home : action === "welcome_cozy" ? LampFloor : PowerOff;
  return (
    <button onClick={run} disabled={busy}
      className={`flex w-full items-center justify-center gap-2 rounded-xl border py-2.5 text-xs disabled:opacity-50 ${cls}`}>
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : done ? <Check className="h-4 w-4 text-emerald-300" /> : <Icon className="h-4 w-4" />}
      {label}
    </button>
  );
}

function RoomThumb({ room, size }: { room: Room; size: number }) {
  if (room.image_url) {
    const isVid = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i.test(room.image_url);
    if (isVid) {
      // #t=0.1 で先頭フレームを静止表示 (ポスター代わり・再生しないので軽い)
      const frame = room.image_url.includes("#") ? room.image_url : `${room.image_url}#t=0.1`;
      return (
        <video src={frame} width={size} height={size} muted playsInline preload="metadata"
          style={{ width: size, height: size }}
          className="shrink-0 rounded-xl bg-black/30 object-cover"
          onError={(e) => { e.currentTarget.style.visibility = "hidden"; }} />
      );
    }
    return (
      <img src={room.image_url} alt={room.display_name} width={size} height={size}
        style={{ width: size, height: size }}
        className="shrink-0 rounded-xl object-cover"
        onError={(e) => { e.currentTarget.style.visibility = "hidden"; }} />
    );
  }
  return (
    <div style={{ width: size, height: size }}
      className="flex shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/30">
      <DoorOpen className="h-1/2 w-1/2" />
    </div>
  );
}

/* ---------------- Device test tab ---------------- */
function DeviceTestSection({ rooms, t }: { rooms: Room[]; t: T }) {
  // 棟ごとに「全部屋の照明・機器を一括OFF」（チェックアウト後の消し忘れ対策）
  const [busy, setBusy] = useState<string | null>(null);
  const [result, setResult] = useState<{ building: string; ok: number; total: number } | null>(null);
  const [armed, setArmed] = useState<string | null>(null); // 誤操作防止: 1度目で武装→2度目で実行
  const [roomBusy, setRoomBusy] = useState<string | null>(null); // 部屋単位OFFの実行中(room.id)
  const [roomDone, setRoomDone] = useState<string | null>(null); // 部屋単位OFFの完了表示(room.id)

  const roomOff = async (room: Room) => {
    if (roomBusy) return;
    blip(); setRoomBusy(room.id); setRoomDone(null);
    try {
      const res = await fetch("/api/admin/test-device", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roomSlug: room.slug, action: "away" }),
      });
      if (res.ok) { setRoomDone(room.id); setTimeout(() => setRoomDone((d) => (d === room.id ? null : d)), 2000); }
    } catch { /* noop */ }
    setRoomBusy(null);
  };

  const allOff = async (building: string, groupRooms: Room[]) => {
    setBusy(building); setResult(null); setArmed(null);
    let ok = 0;
    for (const room of groupRooms) {
      try {
        const res = await fetch("/api/admin/test-device", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ roomSlug: room.slug, action: "away" }),
        });
        if (res.ok) ok++;
      } catch { /* noop */ }
    }
    setBusy(null);
    setResult({ building, ok, total: groupRooms.length });
  };

  return (
    <section>
      <div className="mb-1 flex items-center gap-2 text-sm text-violet-200">
        <Wrench className="h-4 w-4" /> {t.testTitle}
      </div>
      <p className="mb-4 text-xs text-white/40">{t.testDesc}</p>

      {groupByBuilding(rooms).map((group) => {
        const isBusy = busy === group.name;
        const isArmed = armed === group.name;
        const res = result && result.building === group.name ? result : null;
        return (
          <div key={group.name} className="mb-6">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <BuildingBadge name={group.name} />
              <span className="text-[11px] text-white/40">{group.rooms.length} {t.tabRooms}</span>
              <span className="h-px flex-1 bg-white/10" />
              {/* 棟の全部屋を一括OFF（エアコン/照明/ギャラクシー/NEST/和風ライト） */}
              <button
                onClick={() => { blip(); if (isBusy) return; if (isArmed) { allOff(group.name, group.rooms); } else { setArmed(group.name); setTimeout(() => setArmed((a) => (a === group.name ? null : a)), 4000); } }}
                disabled={isBusy}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${isArmed ? "border-rose-400/70 bg-rose-500/25 text-rose-100" : "border-rose-400/40 bg-rose-500/10 text-rose-200"} disabled:opacity-50`}
                title="この棟の全部屋の照明・機器をOFF（チェックアウト後の消し忘れ対策）"
              >
                {isBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PowerOff className="h-3.5 w-3.5" />}
                {isBusy ? "OFF中…" : isArmed ? "もう一度で実行" : "全部屋OFF"}
              </button>
            </div>

            {res && (
              <p className="mb-2 text-[11px] text-emerald-300/90">✓ {res.building}: {res.ok}/{res.total} 部屋をOFFにしました</p>
            )}

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {group.rooms.map((room) => {
                const rBusy = roomBusy === room.id;
                const rDone = roomDone === room.id;
                return (
                  <div key={room.id}
                    className="flex items-center gap-2 rounded-2xl border border-violet-400/30 bg-violet-500/10 px-3 py-2.5">
                    <a href={`/admin/test/${room.slug}`} target="_blank" rel="noopener noreferrer"
                      className="flex min-w-0 flex-1 items-center gap-2 text-sm text-violet-100">
                      <RoomThumb room={room} size={32} />
                      <span className="truncate">{room.display_name}</span>
                      <ExternalLink className="h-3.5 w-3.5 shrink-0 text-violet-300/70" />
                    </a>
                    {/* この部屋だけOFF（エアコン/照明/機器） */}
                    <button
                      onClick={() => roomOff(room)}
                      disabled={rBusy}
                      className={`flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition disabled:opacity-50 ${rDone ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-200" : "border-rose-400/40 bg-rose-500/10 text-rose-200 active:bg-rose-500/25"}`}
                      title="この部屋の照明・機器をOFF"
                    >
                      {rBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : rDone ? <Check className="h-3.5 w-3.5" /> : <PowerOff className="h-3.5 w-3.5" />}
                      {rDone ? "OFF✓" : "OFF"}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </section>
  );
}

/* ---------------- shared ---------------- */
const selCls = "w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white [color-scheme:dark]";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="text-xs text-white/60">{label}<div className="mt-1">{children}</div></label>;
}

/** Airbnb iCal を今すぐ手動同期するボタン (Cronを待たずに新規予約を取り込む)。 */
function SyncNowButton({ t }: { t: T }) {
  const [state, setState] = useState<"idle" | "busy" | "done" | "err">("idle");
  const [msg, setMsg] = useState<string | null>(null);

  const run = async () => {
    if (state === "busy") return;
    blip();
    setState("busy"); setMsg(null);
    try {
      const r = await syncNow();
      if (r.ok) {
        setState("done");
        setMsg(`+${r.added} / ~${r.updated} / -${r.cancelled}`);
      } else {
        setState("err"); setMsg(r.error ?? null);
      }
    } catch (e: any) {
      setState("err"); setMsg(e?.message ?? null);
    }
    setTimeout(() => { setState("idle"); setMsg(null); }, 5000);
  };

  return (
    <button onClick={run} disabled={state === "busy"} title={msg ?? t.syncNow}
      className="flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-2 text-xs text-cyan-100 active:scale-95 disabled:opacity-60">
      {state === "busy" ? <Loader2 className="h-4 w-4 animate-spin" />
        : state === "done" ? <Check className="h-4 w-4 text-emerald-300" />
        : <RefreshCw className="h-4 w-4" />}
      <span className="hidden sm:inline">
        {state === "busy" ? t.syncing : state === "done" ? (msg ?? t.syncDone) : state === "err" ? t.syncFail : t.syncNow}
      </span>
    </button>
  );
}

function LangSwitch({ lang, onChange }: { lang: AdminLang; onChange: (l: AdminLang) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs active:scale-95">
        <Globe className="h-4 w-4 text-cyan-300" /> {ADMIN_LANG_LABEL[lang]}
      </button>
      <AnimatePresence>
        {open && (
          <motion.ul initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
            className="absolute right-0 z-20 mt-2 w-32 overflow-hidden rounded-2xl border border-white/10 bg-[#0a0c14]/90 backdrop-blur-xl">
            {ADMIN_LANGS.map((l) => (
              <li key={l}>
                <button onClick={() => { onChange(l); setOpen(false); }}
                  className={`w-full px-4 py-2.5 text-left text-sm ${l === lang ? "text-cyan-300 bg-cyan-500/10" : "text-white/70 hover:bg-white/5"}`}>
                  {ADMIN_LANG_LABEL[l]}
                </button>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}

function FilterChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={() => { if (!active) navTick(); onClick(); }}
      className={`clip-bevel-sm border px-3 py-1.5 text-xs transition ${active ? "border-cyan-400/50 bg-cyan-500/15 text-cyan-200 shadow-[0_0_14px_-4px_rgba(34,211,238,0.7)]" : "border-white/10 bg-white/5 text-white/60"}`}>
      {label}
    </button>
  );
}

function ReservationCard({ r, rooms, assignMode, t, lang }: { r: Reservation; rooms: Room[]; assignMode: boolean; t: T; lang: AdminLang }) {
  const [copied, setCopied] = useState(false);
  const active = r.status === "active";
  const assigned = !!r.assigned_room_id;
  const copyPin = async () => {
    if (!r.unlock_pin) return;
    await navigator.clipboard.writeText(r.unlock_pin);
    setCopied(true); setTimeout(() => setCopied(false), 1500);
  };
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className={`clip-bevel border bg-[#070a12]/80 p-5 backdrop-blur-xl ${active ? "border-cyan-400/15" : "border-rose-500/25 opacity-60"}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <DoorOpen className="h-4 w-4 text-cyan-300" />
            <span className="font-medium">{r.room_name}</span>
            {assigned && (
              <span className="rounded-full border border-violet-400/40 bg-violet-500/15 px-2 py-0.5 text-[10px] font-semibold text-violet-200">
                → {r.assigned_room_name}
              </span>
            )}
            <span className={`rounded-full px-2 py-0.5 text-[10px] tracking-wide
              ${active ? "bg-emerald-500/15 text-emerald-300" : r.status === "cancelled" ? "bg-rose-500/15 text-rose-300" : "bg-white/10 text-white/50"}`}>
              {r.status}
            </span>
            <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] text-white/50">{r.source === "ical" ? "Airbnb" : t.manual}</span>
            {r.co && (
              <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">✓ {CO_L[lang].done} {fmt(r.co.at, lang)}</span>
            )}
          </div>
          <p className="mt-1.5 text-xs text-white/50">{fmt(r.check_in, lang)} → {fmt(r.check_out, lang)}</p>
          {r.guest_name && <p className="text-xs text-white/40">{r.guest_name}・{r.guest_lang}</p>}
        </div>
        <button onClick={copyPin} className="shrink-0 rounded-2xl border border-cyan-400/30 bg-cyan-500/10 px-4 py-2 text-center">
          <div className="flex items-center gap-1 text-[10px] text-cyan-300/70"><KeyRound className="h-3 w-3" /> {t.pin} {copied ? "✓" : ""}</div>
          <div className="font-mono text-2xl tracking-[0.3em] text-cyan-200">{r.unlock_pin ?? "----"}</div>
        </button>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {r.airbnb_reservation_url && (
          <a href={r.airbnb_reservation_url} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1.5 rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1.5 text-xs text-rose-200">
            <ExternalLink className="h-3.5 w-3.5" /> {t.openAirbnb}
          </a>
        )}
        {/* PINを手動設定 (Airbnb推奨コード等) */}
        <form action={setPin} className="flex items-center gap-1">
          <input type="hidden" name="id" value={r.id} />
          <input name="pin" defaultValue={r.unlock_pin ?? ""} inputMode="numeric" maxLength={6}
            className="w-16 rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-center font-mono text-xs text-cyan-200" />
          <SubmitButton savedText={t.saved} className="rounded-lg border border-cyan-400/40 bg-cyan-500/10 px-2.5 py-1.5 text-xs text-cyan-200">{t.save}</SubmitButton>
        </form>
        <form action={regeneratePin}>
          <input type="hidden" name="id" value={r.id} />
          <SubmitButton savedText={t.saved} idleIcon={<RefreshCw className="h-3.5 w-3.5" />}
            className="flex items-center gap-1.5 rounded-lg border border-amber-400/30 bg-amber-500/10 px-3 py-1.5 text-xs text-amber-200">
            {t.regenPin}
          </SubmitButton>
        </form>
        {active && (
          <form action={cancelReservation}>
            <input type="hidden" name="id" value={r.id} />
            <SubmitButton savedText={t.saved} idleIcon={<Ban className="h-3.5 w-3.5" />}
              className="flex items-center gap-1.5 rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1.5 text-xs text-rose-200">
              {t.cancel}
            </SubmitButton>
          </form>
        )}
      </div>

      {/* 客室割り当て（寄せ）モード時のみ表示。看板を付け替えて別の部屋に泊まらせる。 */}
      {assignMode && (
        <form action={assignReservation} className="mt-3 flex flex-wrap items-center gap-2 border-t border-white/10 pt-3">
          <input type="hidden" name="id" value={r.id} />
          <span className="text-[11px] font-semibold text-violet-200">泊まる部屋</span>
          <select
            name="assigned_room_id"
            defaultValue={r.assigned_room_id ?? ""}
            className="rounded-lg border border-violet-400/30 bg-black/40 px-2 py-1.5 text-xs text-violet-100 [&>option]:text-black"
          >
            <option value="">元の部屋（{r.room_name}）</option>
            {rooms.map((room) => (
              <option key={room.id} value={room.id}>
                {room.display_name}（{room.building || "Crane Nest"}）
              </option>
            ))}
          </select>
          <SubmitButton savedText={t.saved}
            className="rounded-lg border border-violet-400/50 bg-violet-500/15 px-3 py-1.5 text-xs font-semibold text-violet-200">
            割り当て
          </SubmitButton>
        </form>
      )}
    </motion.div>
  );
}
